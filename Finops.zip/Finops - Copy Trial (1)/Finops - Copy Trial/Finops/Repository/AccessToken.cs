﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Web.Http.Filters;

namespace Finops.Repository
{
    public class AccessToken : IAccessToken
    {
        private readonly IConfiguration _configuration;
        public AccessToken(IConfiguration configuration) { 
        
            _configuration= configuration;
        }
        public string AuthenticateCode(string cid, string csecret)
        {
            ClientCredential cc = new ClientCredential(cid, csecret);
            var context = new AuthenticationContext("https://login.microsoftonline.com/" + _configuration.GetSection("TenantId").Value);
            var result = context.AcquireTokenAsync("https://management.azure.com/", cc);

            if (result==null)
            {
                throw new InvalidOperationException("Failed to get the AccessToken");
            }
            return result.Result.AccessToken;

        }
    }
}
