﻿namespace Finops.Models
{
    public class Metric
    {
        public string Name { get; set; }
        public DateTime Timestamp { get; set; }
        public double Value { get; set; }
    }
}
