﻿using Azure;
using Azure.Identity;
using Finops.Models;
using Azure.Monitor.Query.Models;
using Finops.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using System.Diagnostics;
using Microsoft.Azure.Management.ResourceManager.Models;
using System.Xml.Linq;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Web.Http.Results;
using System.Net;

namespace Finops.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class MtestController : ControllerBase
    {
        private const string AzureMonitorEndpoint = "https://management.azure.com/";
        private readonly string _subscriptionId = "8309efe0-60f1-413a-90f0-ee27a0f0dbd2";
        private readonly string _ResourceId = "da3e59ae-984b-4580-991f-33a494213d4c";
        private readonly string _resourceGroupName = "Finops";
        private readonly string _resourceName = "VM1";
        private readonly string _apiVersion = "2021-04-01";
        private readonly List<string> _metricNames = new List<string>
        {
            "Percentage CPU",
            "Used Storage",
            "Available Memory",
            "Network In",
            "Network Out"
        };
    
        private readonly string _timespan = "P30D"; // Specify the timespan for metric data retrieval (30 days)
        private readonly IConfiguration _configuration;
        private readonly IAccessToken _accesstoken;

        public MtestController(IConfiguration configuration, IAccessToken accesstoken)
        {

            _configuration = configuration;
            _accesstoken = accesstoken;
        }
            
        [HttpGet]
        public async Task<IActionResult> GetMetrics()
        {
            using (var client = new HttpClient())
          {
               
                    ClientCredential cc = new ClientCredential(_configuration.GetSection("ClientId").Value, _configuration.GetSection("ClientSecret").Value);
                    var context = new AuthenticationContext("https://login.microsoftonline.com/" + _configuration.GetSection("TenantId").Value);
                    var result = context.AcquireTokenAsync("https://management.azure.com/", cc);
                    Debug.WriteLine("result");
                    Debug.WriteLine(result.Result.AccessToken);
                    if (result == null)
                    {
                        throw new InvalidOperationException("Failed to obtain the Access token");
                    }
                else
                {
                   // Debug.WriteLine($"{result.Result.AccessToken}");
                }
                //  return result;//


                // client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                // client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",_accesstoken.AuthenticateCode(_configuration.GetSection("ClientId").Value, _configuration.GetSection("ClientSecret").Value));

                client.BaseAddress = new Uri(AzureMonitorEndpoint);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accesstoken.AuthenticateCode(_configuration.GetSection("ClientId").Value, _configuration.GetSection("ClientSecret").Value));
                Debug.WriteLine(client.DefaultRequestHeaders.ToString());

                // client.DefaultRequestHeaders.Add("x-api-version"," v2");
                var metricsResponses = new List<Mtest>();
                Debug.WriteLine(_configuration);
                Debug.WriteLine(_configuration.GetSection("ClientSecret").Value);
                Debug.WriteLine(_configuration.GetSection("ClientId").Value);
                Debug.WriteLine(_configuration.GetSection("SubscriptionId").Value);
                // foreach (var metricName in _metricNames)
                //  {

                // String requestUrl = $"https://management.azure.com/subscriptions/{_subscriptionId}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{_resourceName}/providers/Microsoft.Insights/metrics?api-version=2018-01-01&metricnames=UsedCapacity";//
                var requestUrl = $"https://management.azure.com/subscriptions/{_configuration.GetSection("SubscriptionId").Value}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/VM1/providers/Microsoft.Insights/metrics?api-version=2018-01-01&metricnames=UsedCapacity";


                // string requestUrl = $"{AzureMonitorEndpoint}subscriptions/{_subscriptionId}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{_resourceName}/providers/microsoft.insights/metrics?api-version={_apiVersion}&metricnames={metricName}&timespan=2018-06-05T03:00:00Z/2018-06-07T03:00:00Z";
                // string requestUrl = $"https://management.azure.com/subscriptions/{_subscriptionId}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{_resourceName}/providers/microsoft.insights/metrics?api-version=2018-01-01&metricnames=Percentage%20CPU&timespan=2018-06-05T03:00:00Z/2018-06-07T03:00:00Z";
                HttpResponseMessage response = await client.GetAsync(requestUrl);
             //   response.EnsureSuccessStatusCode();

                Debug.WriteLine(requestUrl);
                  //  Debug.WriteLine(response);//
                    if (response.IsSuccessStatusCode)
                    {
                        var metricsResponse = await response.Content.ReadAsAsync<Mtest>();
                        Debug.WriteLine($"Metrics: {metricsResponse}");                     
                        metricsResponses.Add(metricsResponse);
                    }
                    else
                    {
                        Debug.WriteLine(response);
                    }
              //  }
                return Ok(metricsResponses);
            }



           // try
          //  {
             //   var metricsClient = new Mtest();

               // var metricsNames = new List<string> { "Percentage CPU", "Used Storage", "Available Memory", "Network In", "Network Out" };
            //    var metricsResponses = new List<MetricResult>();

              //  foreach (var metricName in metricsNames)
                // {
                   /* var metricsQuery = new MetricsQueryRequest(
                        resourceId: $"/subscriptions/{_subscriptionId}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{_resourceName}",
                        metricNames: new[] { metricName },
                        timeSpan: new TimeSpan(days: 30),
                        interval: TimeSpan.FromDays(1),
                        aggregation: "Average");

                    var metricsResult = await metricsClient.QueryAsync(metricsQuery);
                    metricsResponses.Add(metricsResult.Value[0]);
                }

                return Ok(metricsResponses);
            }
            catch (RequestFailedException ex)
            {
                return StatusCode((int)ex.Status, $"Failed to fetch metrics. {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred. {ex.Message}");
            }*/
        }

    }

    }
