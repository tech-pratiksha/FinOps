﻿using Finops.Models;
using Finops.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Management.ResourceManager;
using Microsoft.Extensions.Configuration;
using Microsoft.Rest;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace AzureMetricsAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MetricsController : ControllerBase
    {
        private const string AzureMonitorEndpoint = "https://management.azure.com";
        private const string AzureMonitorApiVersion = "2018-01-01";

       // private readonly string _subscriptionId;
       // private readonly string _resourceId;
       // private readonly string _accessToken;
       private readonly IConfiguration _configuration;
        private readonly IAccessToken _accesstoken;

        public MetricsController(IConfiguration configuration, IAccessToken accesstoken)
        {
           // _subscriptionId = configuration["Azure:SubscriptionId"];
           // _resourceId = configuration["Azure:ResourceId"];
           // _accessToken = configuration["Azure:AccessToken"];

            _configuration = configuration;
            _accesstoken = accesstoken;
        }

        [HttpGet("Cpu")]
        public async Task<IActionResult> GetCpuMetrics()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    

                    // Set the base address and default request headers
                    client.BaseAddress = new Uri(AzureMonitorEndpoint);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accesstoken.AuthenticateCode(_configuration.GetSection("ClientId").Value, _configuration.GetSection("ClientSecret").Value));


                    // Construct the request URL
                    //var requestUrl = $"/subscriptions/{_configuration.GetSection("SubscriptionId").Value}/providers/microsoft.insights/metrics" +
                    //    $"?api-version={AzureMonitorApiVersion}&$filter=resourceUri eq '{_configuration.GetSection("ResourceId").Value}' and name.value eq 'Percentage CPU'";

                    // Send the GET request to Azure Monitor API
                    var requestUrl = $"https://management.azure.com/subscriptions/8309efe0-60f1-413a-90f0-ee27a0f0dbd2/providers?api-version=2021-04-01";
                    var response = await client.GetAsync(requestUrl);
                    
                    response.EnsureSuccessStatusCode();


                    // Read the response content
                    var responseContent = await response.Content.ReadAsStringAsync();
                    return Ok(responseContent);
                    // Process the response JSON and extract the CPU metric data
                    //var cpuMetrics = ProcessResponse(responseContent);

                    //return Ok(cpuMetrics);
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions and return an appropriate response
                return StatusCode(500, $"An error occurred: {ex.Message}");
            }
        }

        private List<Metric> ProcessResponse(string responseContent)
        {
            var cpuMetrics = new List<Metric>();

            dynamic jsonResponse = Newtonsoft.Json.JsonConvert.DeserializeObject(responseContent);

            foreach (var value in jsonResponse.value)
            {
                var metric = new Metric
                {
                    Name = value.name.value,
                    Timestamp = DateTime.Parse(value.timeseries[0].data[0].timeStamp),
                    Value = double.Parse(value.timeseries[0].data[0].average)
                };

                cpuMetrics.Add(metric);
            }

            return cpuMetrics;
        }
    }

   
    }

