﻿using Azure;
using Azure.Identity;
using Finops.Models;
using Azure.Monitor.Query.Models;
using Finops.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;
using System.Diagnostics;
using Microsoft.Azure.Management.ResourceManager.Models;
using System.Xml.Linq;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Web.Http.Results;
using System.Net;
using Newtonsoft.Json;

namespace Finops.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class MetricController : ControllerBase
    {
        private const string AzureMonitorEndpoint = "https://management.azure.com/";
        private readonly string _subscriptionId = "8309efe0-60f1-413a-90f0-ee27a0f0dbd2";
        private readonly string _ResourceId = "da3e59ae-984b-4580-991f-33a494213d4c";
        private readonly string _resourceGroupName = "Finops";
        private readonly string _resourceName = "VM1";
        private readonly string _apiVersion = "2018-01-01";
        private readonly List<string> _metricNames = new List<string>
        {
            "Percentage CPU",
            "Used Storage",
            "Available Memory",
            "Network In",
            "Network Out"
        };

        private readonly string _timespan = "P30D"; // Specify the timespan for metric data retrieval (30 days)
        private readonly IConfiguration _configuration;
        private readonly IAccessToken _accesstoken;

        public MetricController(IConfiguration configuration, IAccessToken accesstoken)
        {

            _configuration = configuration;
            _accesstoken = accesstoken;
        }

        [HttpGet]
        public async Task<IActionResult> GetMetrics()
        {
            HttpClient client = new HttpClient();
            string responseContent = "";
            try
            {

                // Set the base URL
                string metricName = "Percentage CPU,Available Memory Bytes,CPU Credits Consumed,Network In,Network Out";
                // Create your request object
                string requestUrl = $"{AzureMonitorEndpoint}subscriptions/{_subscriptionId}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{_resourceName}/providers/microsoft.insights/metrics?api-version={_apiVersion}&metricnames={metricName}&timespan=2023-07-09T00:00:00Z/2023-07-11T00:00:00Z";
                var request = new HttpRequestMessage(HttpMethod.Get, requestUrl);
                ClientCredential cc = new ClientCredential(_configuration.GetSection("ClientId").Value, _configuration.GetSection("ClientSecret").Value);
                var context = new AuthenticationContext("https://login.microsoftonline.com/" + _configuration.GetSection("TenantId").Value);
                var result = context.AcquireTokenAsync("https://management.azure.com/", cc);
                Debug.WriteLine("result");
                Debug.WriteLine(result.Result.AccessToken);

                // Add the 'Authorization' header
                string token = result.Result.AccessToken;
                request.Headers.Add("Accept", "application/json");
                request.Headers.Add("Authorization", "Bearer " + token);

                // Send the request and get the response
                HttpResponseMessage response = await client.SendAsync(request);
                Debug.WriteLine("Response: {response.StatusCode}");


                // Read the response content
                responseContent = await response.Content.ReadAsStringAsync();
                Debug.WriteLine("Response: {responseContent}");


                // Deserialize the response JSON
                var responseObject = JsonConvert.DeserializeObject<dynamic>(responseContent);
                Debug.WriteLine($"Response: {responseObject}");
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
            finally

            {
                client.Dispose();
            }
            return Ok(responseContent);

        }
    }
}
