﻿using System;

namespace Finops.Models
{
    public class Metric
    {
        public string PercentageCPU { get; set; }
        public string UsedStorage { get; set; }
        public string AvailableMemory { get; set; }
        public string NetworkIn { get; set; }

        public string NetworkOut { get; set; }
    }
}
