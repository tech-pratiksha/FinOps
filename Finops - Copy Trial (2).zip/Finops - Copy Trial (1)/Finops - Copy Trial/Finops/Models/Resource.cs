﻿namespace Finops.Models
{
    public class Resource
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Owner { get; set; }
        public string Owner_Email_Tag { get; set; }
        public string Ignore_Tag { get; set; }
        public string Target_Productivity { get; set; }
        public string OEE { get; set; }
        public string Action { get; set; }


    }
}
