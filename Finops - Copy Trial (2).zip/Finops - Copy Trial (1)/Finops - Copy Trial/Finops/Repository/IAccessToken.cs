﻿namespace Finops.Repository
{
    public interface IAccessToken
    {
        string AuthenticateCode(string cid, string csecret);
    }
}
