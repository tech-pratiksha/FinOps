﻿using Azure;
using Azure.Identity;
using Finops.Models;
using Finops.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Headers;


namespace Finops.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MtestController : ControllerBase
    {
        private const string AzureMonitorEndpoint = "https://management.azure.com";
        private readonly string _subscriptionId = "8309efe0-60f1-413a-90f0-ee27a0f0dbd2";
        private readonly string _resourceGroupName = "Finops";
        private readonly string _resourceName = "VM1";
        private readonly string _apiVersion = "2021-04-01";
        private readonly List<string> _metricNames = new List<string>
        {
            "Percentage CPU",
            "Used Storage",
            "Available Memory",
            "Network In",
            "Network Out"
        };
        private readonly string _timespan = "P30D"; // Specify the timespan for metric data retrieval (30 days)
        private readonly IConfiguration _configuration;
        private readonly IAccessToken _accesstoken;

        public MtestController(IConfiguration configuration, IAccessToken accesstoken)
        {

            _configuration = configuration;
            _accesstoken = accesstoken;
        }

        [HttpGet]
        public async Task<IActionResult> GetMetrics()
        {
            //using (var client = new HttpClient())
            //{
            //    client.BaseAddress = new Uri(AzureMonitorEndpoint);
            //    client.DefaultRequestHeaders.Accept.Clear();
            //    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accesstoken.AuthenticateCode(_configuration.GetSection("ClientId").Value, _configuration.GetSection("ClientSecret").Value));

            //    var metricsResponses = new List<Mtest>();
            //    foreach (var metricName in _metricNames)
            //    {
            //        string requestUrl = $"https://management.azure.com/subscriptions/{_configuration.GetSection("SubscriptionId").Value}/providers/Microsoft.Compute/virtualMachines/{_configuration.GetSection("ResourceName").Value}/providers/microsoft.insights/metrics?api-version={_apiVersion}&$filter=mname eq '{metricName}'&interval=PT1H&aggregation=Average&timespan={_timespan}";

            //        HttpResponseMessage response = await client.GetAsync(requestUrl);
            //        Console.Write(response);
            //        if (response.IsSuccessStatusCode)
            //        {
            //            var metricsResponse = await response.Content.ReadAsAsync<Mtest>();
            //            metricsResponses.Add(metricsResponse);
            //        }
            //    }
            //    return Ok(metricsResponses);
            //}



            try
            {
                var metricsClient = new MetricsClient(new DefaultAzureCredential());

                var metricsNames = new List<string> { "Percentage CPU", "Used Storage", "Available Memory", "Network In", "Network Out" };
                var metricsResponses = new List<MetricResult>();

                foreach (var metricName in metricsNames)
                {
                    var metricsQuery = new MetricsQueryRequest(
                        resourceId: $"/subscriptions/{_subscriptionId}/resourceGroups/{_resourceGroupName}/providers/Microsoft.Compute/virtualMachines/{_resourceName}",
                        metricNames: new[] { metricName },
                        timeSpan: new TimeSpan(days: 30),
                        interval: TimeSpan.FromDays(1),
                        aggregation: "Average");

                    var metricsResult = await metricsClient.QueryAsync(metricsQuery);
                    metricsResponses.Add(metricsResult.Value[0]);
                }

                return Ok(metricsResponses);
            }
            catch (RequestFailedException ex)
            {
                return StatusCode((int)ex.Status, $"Failed to fetch metrics. {ex.Message}");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred. {ex.Message}");
            }
        }


    }

    }
}
